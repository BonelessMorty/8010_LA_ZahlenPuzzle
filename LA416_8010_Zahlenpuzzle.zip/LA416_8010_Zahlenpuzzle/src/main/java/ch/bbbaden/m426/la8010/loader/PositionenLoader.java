package ch.bbbaden.m426.la8010.loader;

/**
 *
 * @author Manuel Bachofner
 */


public interface PositionenLoader {
    public int[][] getPositionen(int zeilen, int spalten);
}
