

package ch.bbbaden.m426.la8010.view;

import ch.bbbaden.m426.la8010.spiel.Spiel;

/**
 *
 * @author Manuel Bachofner
 */
public interface Gui {
    
    public void spiele(Spiel spiel);
    public  void  ziehe(int wert); //Nur für die Automatisation
}
